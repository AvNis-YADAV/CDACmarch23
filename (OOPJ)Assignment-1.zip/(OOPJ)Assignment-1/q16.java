public class q16 {
    public static void main(String[] args) {
      /* 
      int s=200;
      String str=Integer.toString(s);
      System.out.println(str);
      System.out.println(str.getClass());
    */

      
      //int s=200;
      //Integer a=Integer.valueOf(s);
     // System.out.println(a);
      //System.out.println(a.getClass());
      
      
      //String str =new String("2005");
      //Integer s=Integer.valueOf(str);
      //System.out.println(s.getClass());

      int s=200;
      System.out.println("int "+s+" convert to binary string "+Integer.toBinaryString(s));
      
      System.out.println("int "+s+" convert to Octal string "+Integer.toOctalString(s));
      
      System.out.println("int "+s+" convert to hexaDecimal string "+Integer.toHexString(s));
      
}
}