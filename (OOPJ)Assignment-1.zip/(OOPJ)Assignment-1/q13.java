class q13{
      public static void main(String[] args) {
        /* 
        short s=200;
        String str=Short.toString(s);
        System.out.println(str);
        System.out.println(str.getClass());
         */

        /* 
        short s=200;
        Short a=Short.valueOf(s);
        System.out.println(a);
        System.out.println(a.getClass());
         */

        String str =new String("2005");
        Short s=Short.valueOf(str);
        System.out.println(s.getClass());
 }
}
