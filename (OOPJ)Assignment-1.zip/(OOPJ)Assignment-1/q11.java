public class q11 {
    public static void main(String[] args){
       String s=args[0];
       Character a=s.charAt(0);
       if(Character.isDigit(a))
       {
        int Codepoint=(int)a;
        System.out.println("Its a digit and its Codepoint is " + Codepoint);
       }
       else if (Character.isLetter(a)) 
    {
        int Codepoint=(int)a;
        System.out.println("Its a letter and its Codepoint is " + Codepoint);
        if(Character.isLowerCase(a)){
            System.out.println(a+" converted to " + Character.toUpperCase(a));
        }
        else if(Character.isUpperCase(a))

        {
            System.out.println(a+" converted to " + Character.toLowerCase(a));
        }
    }
       

    }
}