public class q18 {
    public  static void main(String[] args){
        int a=50;
        int b=-40;
        int c=Integer.max(a, b);
        int d=Integer.min(a, b);
        System.out.println(c+" is MAXIMUM!");
        System.out.println(d+" is MINIMUM!");
        System.out.println("Sum of "+a+" & "+b+" = "+Integer.sum(a, b));

    }
}