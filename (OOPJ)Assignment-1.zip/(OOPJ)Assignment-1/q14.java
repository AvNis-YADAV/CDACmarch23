class q14{
    public static void main(String[] args) {
        short q=99;
		Short B=new Short(q);

		short s=B.shortValue();
        byte b=B.byteValue();
	    int i=B.intValue();
	    long l=B.longValue();
	    float f=B.floatValue();
	    double d=B.doubleValue();


System.out.println("Initially var was short");	    
System.out.println(((Object)b).getClass().getName());	    
System.out.println(((Object)i).getClass().getName());	    
System.out.println(((Object)s).getClass().getName());	   
System.out.println(((Object)l).getClass().getName());
System.out.println(((Object)f).getClass().getName());
System.out.println(((Object)d).getClass().getName());
    }
}