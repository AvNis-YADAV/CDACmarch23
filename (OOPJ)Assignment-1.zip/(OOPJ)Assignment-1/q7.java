/*
static int	BYTES
       The number of bytes used to represent a byte value in two's complement binary form.
static byte	MAX_VALUE
       A constant holding the maximum value a byte can have, 27-1.
static byte	MIN_VALUE
        A constant holding the minimum value a byte can have, -27.
static int	SIZE
       The number of bits used to represent a byte value in two's complement binary form.
static Class<Byte>	TYPE
    The Class instance representing the primitive type byte.
*/
public class q7 {
    public static void main(String args[]){
        System.out.println("Size of Byte in bits= "+Byte.SIZE);
        System.out.println("Size of Byte in bytes= "+Byte.BYTES);
        System.out.println("Min Value of Byte= "+Byte.MIN_VALUE);
        System.out.println("MAx value of Byte= "+Byte.MAX_VALUE);
    }
}

