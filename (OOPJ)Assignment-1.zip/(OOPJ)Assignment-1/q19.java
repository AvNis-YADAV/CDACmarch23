public class q19 {
    public  static void main(String[] args){
        System.out.println("Size of Long in bits= "+Long.SIZE);
        System.out.println("Size of Long in bytes= "+Long.BYTES);
        System.out.println("Min Value of Long= "+Long.MIN_VALUE);
        System.out.println("MAx value of Long= "+Long.MAX_VALUE); 
    }
}
