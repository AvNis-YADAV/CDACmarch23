public class q20 {
    public static void main(String[] args) {
      
      long s=200l;
      String str=Long.toString(s);
      System.out.println(str);
      System.out.println(str.getClass());
    

      
      //long s=200l;
      //Long a=Long.valueOf(s);
     // System.out.println(a);
      //System.out.println(a.getClass());
      
      
      //String str =new String("2005");
      //System.out.println(str+" "+str.getClass());
      //Long s=Long.valueOf(str);
      //System.out.println(str+" String to "+s.getClass());

      //long s=200l;
      //System.out.println("long "+s+" convert to binary string "+Long.toBinaryString(s));
      
      //System.out.println("long "+s+" convert to octal string "+Long.toOctalString(s));
      
      //System.out.println("long "+s+" convert to hexaDecimal string "+Long.toHexString(s));
      
}
}