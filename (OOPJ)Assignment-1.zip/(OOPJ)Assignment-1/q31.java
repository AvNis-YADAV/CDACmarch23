public class q31 {
    public static void main(String[] args) throws Exception{
        String s ="Hello";
        try {
        System.out.println(Integer.parseInt(s));
        } 
        catch (NumberFormatException e) {
            System.out.println("U r trying to parse sring to Number");
        }
    }
}
