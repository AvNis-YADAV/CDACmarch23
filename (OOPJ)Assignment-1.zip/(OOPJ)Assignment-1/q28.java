public class q28 {
    public static void main(String[] args) {
      
      //double s=20.2;
      //String str=Double.toString(s);
      //System.out.println(str);
      //System.out.println(str.getClass());
    
        //double s=20.3;
        //Double a=Double.valueOf(s);
       // System.out.print(a+" ");
        //System.out.println(a.getClass());
      
      
      //String str =new String("2005");
      //System.out.println(str+" "+str.getClass());
      //Double s=Double.valueOf(str);
      //System.out.println(str+" String to "+s.getClass());

       double s=20.3;
       Double.doubleToLongBits(s);
      System.out.println("Double "+s+" convert to binary string "+Long.toBinaryString(Double.doubleToLongBits(s)));
      System.out.println("Double "+s+" convert to octal string "+Long.toOctalString(Double.doubleToLongBits(s)));
      System.out.println("Double "+s+" convert to hexaDecimal string "+Double.toHexString(s));
}
}
