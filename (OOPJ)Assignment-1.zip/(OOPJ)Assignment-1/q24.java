public class q24 {
    public static void main(String[] args) {
      
      //float s=20.2f;
      //String str=Float.toString(s);
      //System.out.println(str);
      //System.out.println(str.getClass());
    
        //float s=20.3f;
        //Float a=Float.valueOf(s);
        //System.out.println(a);
        //System.out.println(a.getClass());
      
      
      //String str =new String("2005");
      //System.out.println(str+" "+str.getClass());
      //Float s=Float.valueOf(str);
      //System.out.println(str+" String to "+s.getClass());

      float s=20.3f;
      System.out.println("float "+s+" convert to hexaDecimal string "+Float.toHexString(s));
      
}
}