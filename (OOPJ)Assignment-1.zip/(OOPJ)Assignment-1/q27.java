public class q27 {
    public  static void main(String[] args){
        System.out.println("Size of Double in bits= "+Double.SIZE);
        System.out.println("Size of Double in bytes= "+Double.BYTES);
        System.out.println("Min Value of Double= "+Double.MIN_VALUE);
        System.out.println("MAx value of Double= "+Double.MAX_VALUE); 
    }
}