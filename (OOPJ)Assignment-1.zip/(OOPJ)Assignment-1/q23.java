public class q23 {
    public  static void main(String[] args){
        System.out.println("Size of Float in bits= "+Float.SIZE);
        System.out.println("Size of Float in bytes= "+Float.BYTES);
        System.out.println("Min Value of Float= "+Float.MIN_VALUE);
        System.out.println("MAx value of Float= "+Float.MAX_VALUE); 
    }
}