public class q9 {
	public static void main(String[] args) {
	    byte q=99;
		Byte B=new Byte(q);
		byte b=B.byteValue();
	    int i=B.byteValue();
	    short s=B.shortValue();
	    long l=B.longValue();
	    float f=B.floatValue();
	    double d=B.doubleValue();
	    
System.out.println(((Object)b).getClass().getName());	    
System.out.println(((Object)i).getClass().getName());	    
System.out.println(((Object)s).getClass().getName());	   
System.out.println(((Object)l).getClass().getName());
System.out.println(((Object)f).getClass().getName());
System.out.println(((Object)d).getClass().getName());
	}
}
