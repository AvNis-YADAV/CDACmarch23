public class q26 {
    public  static void main(String[] args){
        float a=50.26f;
        float b=-36.26f;
        float c=Float.max(a, b);
        float d=Float.min(a, b);
        System.out.println(c+" is MAXIMUM!");
        System.out.println(d+" is MINIMUM!");
        System.out.println("Sum of "+a+" & "+b+" = "+Float.sum(a, b));

    }
}