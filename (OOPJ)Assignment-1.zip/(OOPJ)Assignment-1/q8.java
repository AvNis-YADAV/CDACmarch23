/*
 Write a program to convert:
a. byte value into String
b. byte value into Byte instance.
c. String instance into Byte instance.
 */
public class q8 {
    public static void main(String args[]){
        /* 
       byte b=100;
       String a=Byte.toString(b);
       System.out.println(a+" is from "+a.getClass());
       */

      // byte b=100;
      // Byte a=Byte.valueOf(b);
       //System.out.println(a+" is from "+a.getClass());

       String a=new String("123");
       System.out.println(a+" is from "+a.getClass());
      // String.toString(a);
      Byte b= Byte.valueOf(a);
       System.out.println(b+" is from "+b.getClass());

    }
}