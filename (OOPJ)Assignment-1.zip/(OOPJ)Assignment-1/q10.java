

public class q10 {
    public static void main(String[] args) {
        System.out.println("Size of Char in bits= "+Character.SIZE);
        System.out.println("Size of Char in bytes= "+Character.BYTES);
        System.out.println("Min Value of char= "+(int)Character.MIN_VALUE);
        System.out.println("MAx value of char= "+(int)Character.MAX_VALUE);
    }
}


