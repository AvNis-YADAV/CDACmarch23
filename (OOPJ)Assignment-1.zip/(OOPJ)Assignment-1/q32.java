public class q32 {
    public static void main(String args[]){
        System.out.print("Welcome ");
        for(int i=0; i<args.length; i++){
        System.out.print(args[i]+" ");
        }
    }
}
