public class q22 {
    public  static void main(String[] args){
        long a=500000000l;
        long b=-40000000l;
        long c=Long.max(a, b);
        long d=Long.min(a, b);
        System.out.println(c+" is MAXIMUM!");
        System.out.println(d+" is MINIMUM!");
        System.out.println("Sum of "+a+" & "+b+" = "+Long.sum(a, b));

    }
}