public class q12 {
  public static void main(String[] args) {
            System.out.println("Size of Short in bits= "+Short.SIZE);
            System.out.println("Size of Short in bytes= "+Short.BYTES);
            System.out.println("Min Value of Short= "+Short.MIN_VALUE);
            System.out.println("MAx value ofShortr= "+Short.MAX_VALUE);
  }
}
