
/*
.Write a program to perform below operations on Boolean type to
convert:
a. boolean value into String
b. boolean value into Boolean instance.
c. String value into boolean value
d. String value into Boolean instance.
*/
/*class q6{
    public static void main(String[] args){
        boolean b=true;
        String t=Boolean.toString(b);
      
        System.out.println(t.getClass());

    }
}*/

/* 
class q6{
    public static void main(String[] args){
        boolean b=true;
        Boolean t=Boolean.valueOf(b);
        if(b==t){System.out.println("Object Created");}
        else{System.out.println("Object not Created");};
    }
}
*/

/* 
class q6{
public static void main(String[] args){
        String b="TRUE";
       boolean t= Boolean.parseBoolean(b);
       System.out.println(t);
    }
}
*/

class q6{
    public static void main(String[] args){
        String b="true";
        Boolean t= Boolean.valueOf(b);
      if(t==true)  
    {System.out.println(t.getClass());
    System.out.println(t);}
    }
}
