public class q30 {
    public  static void main(String[] args){
        double a=50.26d;
        double b=-30.26d;
        double c=Double.max(a, b);
        double d=Double.min(a, b);
        System.out.println(c+" is MAXIMUM!");
        System.out.println(d+" is MINIMUM!");
        System.out.println("Sum of "+a+" & "+b+" = "+Double.sum(a, b));

    }
}