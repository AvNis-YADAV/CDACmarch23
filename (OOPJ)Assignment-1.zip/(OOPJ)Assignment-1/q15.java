public class q15 {
    public  static void main(String[] args){
            System.out.println("Size of Int in bits= "+Integer.SIZE);
            System.out.println("Size of Int in bytes= "+Integer.BYTES);
            System.out.println("Min Value of Int= "+Integer.MIN_VALUE);
            System.out.println("MAx value of Int= "+Integer.MAX_VALUE);
    }
}
